# ETL Pipeline Framework

A production-style, modular ETL framework built in Python using **Apache Airflow** for orchestration and **dbt** for transformations. Ingests data from multiple sources (REST APIs, CSV, PostgreSQL), validates quality at every stage, transforms into a star-schema warehouse model, and loads to Snowflake.

---

## Features

- **Pluggable architecture** — add new sources by implementing a 3-method `BaseExtractor` interface
- **Automated data validation** using Great Expectations at each pipeline stage
- **Slack alerting** on pipeline failure with error context and retry logic
- **dbt models** with auto-generated lineage docs via `dbt docs generate`
- **One-command local dev** via Docker Compose

---

## Project Structure

```
etl-pipeline-framework/
├── dags/                        # Airflow DAG definitions
│   └── etl_pipeline_dag.py
├── etl/
│   ├── extractors/              # Source connectors
│   │   ├── base.py
│   │   ├── api_extractor.py
│   │   ├── csv_extractor.py
│   │   └── postgres_extractor.py
│   ├── transformers/            # Transformation logic
│   │   ├── base.py
│   │   └── sales_transformer.py
│   ├── loaders/                 # Destination connectors
│   │   ├── base.py
│   │   └── snowflake_loader.py
│   ├── validators/              # Data quality checks
│   │   └── data_validator.py
│   └── pipeline.py              # Pipeline orchestrator
├── dbt/                         # dbt project
│   ├── models/
│   │   ├── staging/
│   │   └── marts/
│   └── tests/
├── tests/                       # Unit tests
├── config/
│   └── pipeline_config.yml      # Pipeline configuration
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

---

## Quickstart

### 1. Clone and configure

```bash
git clone https://github.com/your-username/etl-pipeline-framework.git
cd etl-pipeline-framework
cp .env.example .env
# Fill in your credentials in .env
```

### 2. Spin up with Docker Compose

```bash
docker-compose up -d
```

This starts:
- Airflow webserver at `http://localhost:8080`
- Airflow scheduler
- PostgreSQL (metadata + source data)
- Redis (Celery broker)

### 3. Run tests

```bash
pip install -r requirements.txt
pytest tests/ -v
```

### 4. Run a pipeline manually

```bash
python -m etl.pipeline --config config/pipeline_config.yml --source api
```

### 5. Generate dbt docs

```bash
cd dbt
dbt deps
dbt docs generate
dbt docs serve  # Opens at http://localhost:8081
```

---

## Configuration

Edit `config/pipeline_config.yml` to define sources, destinations, and validation rules:

```yaml
pipeline:
  name: sales_etl
  schedule: "0 6 * * *"   # Daily at 6am UTC

sources:
  - name: sales_api
    type: api
    endpoint: https://api.example.com/sales
    auth_type: bearer

destinations:
  - name: snowflake_warehouse
    type: snowflake
    schema: raw

validation:
  fail_on_critical: true
  slack_channel: "#data-alerts"
```

---

## Adding a New Source

Implement `BaseExtractor` in `etl/extractors/`:

```python
from etl.extractors.base import BaseExtractor
import pandas as pd

class MyNewExtractor(BaseExtractor):
    def connect(self) -> None:
        pass

    def extract(self) -> pd.DataFrame:
        pass

    def close(self) -> None:
        pass
```

Register it in `config/pipeline_config.yml` and it's ready to use.

---

## Environment Variables

| Variable | Description |
|---|---|
| `SNOWFLAKE_ACCOUNT` | Snowflake account identifier |
| `SNOWFLAKE_USER` | Snowflake username |
| `SNOWFLAKE_PASSWORD` | Snowflake password |
| `SNOWFLAKE_DATABASE` | Target database |
| `SNOWFLAKE_WAREHOUSE` | Compute warehouse name |
| `POSTGRES_HOST` | Source PostgreSQL host |
| `POSTGRES_DB` | Source database name |
| `SLACK_WEBHOOK_URL` | Slack incoming webhook for alerts |
| `API_BEARER_TOKEN` | Auth token for REST API source |
| `AIRFLOW__CORE__FERNET_KEY` | Airflow encryption key |

---

## Data Quality

Validation runs at three stages:

1. **Post-extract** — schema check, null check, row count assertion
2. **Post-transform** — business rule checks (e.g., positive amounts, valid dates)
3. **Post-load** — source vs destination row count reconciliation

Failed critical checks halt the pipeline and trigger a Slack alert.

---

## License

MIT
