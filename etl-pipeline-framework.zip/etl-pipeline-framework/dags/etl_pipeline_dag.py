"""
Airflow DAG: Sales ETL Pipeline
Schedule: Daily at 06:00 UTC
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.empty import EmptyOperator

from etl.pipeline import run_pipeline

DEFAULT_ARGS = {
    "owner": "data-engineering",
    "depends_on_past": False,
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
}

CONFIG_PATH = "/opt/airflow/config/pipeline_config.yml"


def extract_task(**context):
    """Extract raw data from configured source."""
    from etl.extractors.api_extractor import APIExtractor
    import yaml
    with open(CONFIG_PATH) as f:
        config = yaml.safe_load(f)
    extractor = APIExtractor(config["sources"][0])
    df = extractor.run()
    # Push row count to XCom for downstream monitoring
    context["ti"].xcom_push(key="extracted_rows", value=len(df))
    # Persist to temp storage (in prod, write to S3/GCS)
    df.to_parquet("/tmp/raw_data.parquet", index=False)
    return len(df)


def validate_extract_task(**context):
    """Run post-extract validation checks."""
    import pandas as pd
    from etl.validators.data_validator import DataValidator
    df = pd.read_parquet("/tmp/raw_data.parquet")
    validator = DataValidator(stage="post_extract", fail_on_critical=True)
    validator.add_min_rows(1)
    validator.add_not_null("order_id")
    validator.validate(df)


def transform_task(**context):
    """Apply transformations to raw data."""
    import pandas as pd
    from etl.transformers.sales_transformer import SalesTransformer
    df = pd.read_parquet("/tmp/raw_data.parquet")
    transformer = SalesTransformer(config={"name": "sales_etl"})
    clean_df = transformer.run(df)
    clean_df.to_parquet("/tmp/clean_data.parquet", index=False)
    context["ti"].xcom_push(key="transformed_rows", value=len(clean_df))


def validate_transform_task(**context):
    """Run post-transform validation checks."""
    import pandas as pd
    from etl.validators.data_validator import DataValidator, Severity
    df = pd.read_parquet("/tmp/clean_data.parquet")
    validator = DataValidator(stage="post_transform", fail_on_critical=True)
    validator.add_not_null("order_id")
    validator.add_not_null("amount")
    validator.add_value_range("amount", min_val=0, severity=Severity.WARNING)
    validator.validate(df)


def load_task(**context):
    """Load clean data into Snowflake."""
    import pandas as pd
    import yaml
    from etl.loaders.snowflake_loader import SnowflakeLoader
    df = pd.read_parquet("/tmp/clean_data.parquet")
    with open(CONFIG_PATH) as f:
        config = yaml.safe_load(f)
    loader = SnowflakeLoader(config["destinations"][0])
    rows = loader.run(df)
    context["ti"].xcom_push(key="loaded_rows", value=rows)


with DAG(
    dag_id="sales_etl_pipeline",
    default_args=DEFAULT_ARGS,
    description="Daily sales ETL: API → Snowflake via dbt star schema",
    schedule_interval="0 6 * * *",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["etl", "sales", "snowflake"],
) as dag:

    start = EmptyOperator(task_id="start")

    extract = PythonOperator(
        task_id="extract",
        python_callable=extract_task,
    )

    validate_extract = PythonOperator(
        task_id="validate_extract",
        python_callable=validate_extract_task,
    )

    transform = PythonOperator(
        task_id="transform",
        python_callable=transform_task,
    )

    validate_transform = PythonOperator(
        task_id="validate_transform",
        python_callable=validate_transform_task,
    )

    load = PythonOperator(
        task_id="load",
        python_callable=load_task,
    )

    end = EmptyOperator(task_id="end")

    start >> extract >> validate_extract >> transform >> validate_transform >> load >> end
