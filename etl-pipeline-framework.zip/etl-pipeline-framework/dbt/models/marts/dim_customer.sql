-- dim_customer: Customer dimension table.
-- Deduplicates on customer_id, keeping the most recent record.

with customers as (
    select * from {{ source('raw', 'customers') }}
),

deduped as (
    select *,
        row_number() over (
            partition by customer_id
            order by updated_at desc
        ) as rn
    from customers
),

final as (
    select
        customer_id::varchar    as customer_id,
        customer_name::varchar  as customer_name,
        email::varchar          as email,
        lower(trim(segment))    as customer_segment,
        country::varchar        as country,
        created_at::date        as created_at,
        updated_at::timestamp   as updated_at
    from deduped
    where rn = 1
)

select * from final
