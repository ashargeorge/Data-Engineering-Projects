-- fct_orders: Order-grain fact table.
-- Joins staged sales with dim_customer for enriched analytics-ready records.

with orders as (
    select * from {{ ref('stg_sales') }}
),

customers as (
    select * from {{ ref('dim_customer') }}
),

final as (
    select
        o.order_id,
        o.customer_id,
        c.customer_name,
        c.customer_segment,
        c.country,
        o.order_date,
        date_trunc('month', o.order_date)   as order_month,
        date_trunc('quarter', o.order_date) as order_quarter,
        o.status,
        o.amount                            as revenue,
        o.discount_amount,
        o.amount - o.discount_amount        as net_revenue,
        case when o.status = 'refunded' then o.amount else 0 end as refunded_amount,
        case when o.status = 'completed' then 1 else 0 end       as is_completed,
        o.dbt_updated_at
    from orders o
    left join customers c using (customer_id)
)

select * from final
