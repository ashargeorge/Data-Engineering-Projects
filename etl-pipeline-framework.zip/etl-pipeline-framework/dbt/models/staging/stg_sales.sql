-- stg_sales: Casts and renames raw sales columns into a clean staging layer.
-- Filters out records with null order_id or negative amounts.

with source as (
    select * from {{ source('raw', 'sales') }}
),

staged as (
    select
        order_id::varchar                        as order_id,
        customer_id::varchar                     as customer_id,
        amount::numeric(18, 2)                   as amount,
        order_date::date                         as order_date,
        lower(trim(status))                      as status,
        coalesce(discount_amount, 0)::numeric(18,2) as discount_amount,
        loaded_at::timestamp_ntz                 as loaded_at,
        current_timestamp()                      as dbt_updated_at
    from source
    where
        order_id is not null
        and amount >= 0
)

select * from staged
