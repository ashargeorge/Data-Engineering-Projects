"""REST API extractor with bearer token auth, pagination, and retry logic."""

import os
import time
import logging
import requests
import pandas as pd
from typing import Optional
from etl.extractors.base import BaseExtractor

logger = logging.getLogger(__name__)


class APIExtractor(BaseExtractor):
    """
    Extracts data from a paginated REST API.

    Supports:
    - Bearer token authentication
    - Cursor-based and page-based pagination
    - Exponential backoff on 429/5xx errors
    - Configurable timeout and max retries
    """

    MAX_RETRIES = 3
    BACKOFF_BASE = 2  # seconds

    def __init__(self, config: dict):
        super().__init__(config)
        self.endpoint = config["endpoint"]
        self.auth_type = config.get("auth_type", "bearer")
        self.token = os.getenv("API_BEARER_TOKEN")
        self.params = config.get("params", {})
        self.page_size = config.get("page_size", 500)
        self.timeout = config.get("timeout", 30)
        self._session: Optional[requests.Session] = None

    def connect(self) -> None:
        self._session = requests.Session()
        if self.auth_type == "bearer":
            if not self.token:
                raise EnvironmentError("API_BEARER_TOKEN env var is not set")
            self._session.headers.update({"Authorization": f"Bearer {self.token}"})
        logger.info(f"[{self.source_name}] Session opened → {self.endpoint}")

    def extract(self) -> pd.DataFrame:
        all_records = []
        page = 1

        while True:
            params = {**self.params, "page": page, "per_page": self.page_size}
            data = self._get_with_retry(params)

            records = data.get("data", data if isinstance(data, list) else [])
            if not records:
                break

            all_records.extend(records)
            logger.debug(f"[{self.source_name}] Page {page}: {len(records)} records")

            # Stop if we got fewer records than requested (last page)
            if len(records) < self.page_size:
                break
            page += 1

        return pd.DataFrame(all_records)

    def _get_with_retry(self, params: dict) -> dict:
        for attempt in range(self.MAX_RETRIES):
            try:
                response = self._session.get(
                    self.endpoint, params=params, timeout=self.timeout
                )
                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", self.BACKOFF_BASE ** attempt))
                    logger.warning(f"Rate limited. Sleeping {retry_after}s before retry {attempt + 1}")
                    time.sleep(retry_after)
                    continue
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise
                sleep = self.BACKOFF_BASE ** attempt
                logger.warning(f"Request failed ({e}). Retry {attempt + 1}/{self.MAX_RETRIES} in {sleep}s")
                time.sleep(sleep)

    def close(self) -> None:
        if self._session:
            self._session.close()
            self._session = None
