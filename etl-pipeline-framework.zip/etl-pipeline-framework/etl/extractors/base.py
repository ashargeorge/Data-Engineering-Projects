"""Base extractor interface. All source connectors must implement this."""

from abc import ABC, abstractmethod
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class BaseExtractor(ABC):
    """
    Abstract base class for all data extractors.

    To add a new source, subclass BaseExtractor and implement
    the three abstract methods: connect(), extract(), close().

    Example:
        class MySFTPExtractor(BaseExtractor):
            def connect(self): ...
            def extract(self) -> pd.DataFrame: ...
            def close(self): ...
    """

    def __init__(self, config: dict):
        self.config = config
        self.source_name = config.get("name", self.__class__.__name__)
        self._connection = None

    @abstractmethod
    def connect(self) -> None:
        """Establish connection to the data source."""

    @abstractmethod
    def extract(self) -> pd.DataFrame:
        """Extract data and return as a DataFrame."""

    @abstractmethod
    def close(self) -> None:
        """Release resources and close the connection."""

    def run(self) -> pd.DataFrame:
        """
        Orchestrates connect → extract → close with error handling.
        Call this instead of extract() directly.
        """
        logger.info(f"[{self.source_name}] Starting extraction")
        try:
            self.connect()
            df = self.extract()
            logger.info(f"[{self.source_name}] Extracted {len(df):,} rows")
            return df
        except Exception as e:
            logger.error(f"[{self.source_name}] Extraction failed: {e}")
            raise
        finally:
            self.close()

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(source={self.source_name!r})"
