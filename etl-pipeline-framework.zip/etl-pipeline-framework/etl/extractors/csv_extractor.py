"""CSV / flat-file extractor with schema validation and encoding detection."""

import logging
import pandas as pd
from pathlib import Path
from etl.extractors.base import BaseExtractor

logger = logging.getLogger(__name__)


class CSVExtractor(BaseExtractor):
    """
    Extracts data from a CSV file (local or S3 path).

    Supports:
    - Automatic encoding detection (utf-8, latin-1, cp1252)
    - Configurable delimiter, quoting, and date parsing
    - Column whitelist filtering
    - Row count validation
    """

    ENCODINGS = ["utf-8", "latin-1", "cp1252"]

    def __init__(self, config: dict):
        super().__init__(config)
        self.file_path = config["file_path"]
        self.delimiter = config.get("delimiter", ",")
        self.date_columns = config.get("date_columns", [])
        self.columns = config.get("columns")  # Optional column whitelist
        self.min_rows = config.get("min_rows", 1)

    def connect(self) -> None:
        path = Path(self.file_path)
        if not path.exists():
            raise FileNotFoundError(f"CSV file not found: {self.file_path}")
        logger.info(f"[{self.source_name}] File found: {path} ({path.stat().st_size / 1024:.1f} KB)")

    def extract(self) -> pd.DataFrame:
        df = self._read_with_encoding_fallback()

        if self.columns:
            missing = set(self.columns) - set(df.columns)
            if missing:
                raise ValueError(f"Expected columns not found in CSV: {missing}")
            df = df[self.columns]

        for col in self.date_columns:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors="coerce")

        if len(df) < self.min_rows:
            raise ValueError(f"CSV has {len(df)} rows, expected at least {self.min_rows}")

        return df

    def _read_with_encoding_fallback(self) -> pd.DataFrame:
        for encoding in self.ENCODINGS:
            try:
                df = pd.read_csv(
                    self.file_path,
                    sep=self.delimiter,
                    encoding=encoding,
                    low_memory=False,
                )
                logger.debug(f"[{self.source_name}] Read with encoding={encoding}")
                return df
            except UnicodeDecodeError:
                logger.warning(f"[{self.source_name}] Encoding {encoding} failed, trying next")
        raise ValueError(f"Could not read {self.file_path} with any supported encoding")

    def close(self) -> None:
        pass  # No persistent connection for file reads
