"""PostgreSQL extractor using SQLAlchemy with chunked reads for large tables."""

import os
import logging
import pandas as pd
import sqlalchemy as sa
from typing import Optional
from etl.extractors.base import BaseExtractor

logger = logging.getLogger(__name__)


class PostgresExtractor(BaseExtractor):
    """
    Extracts data from a PostgreSQL database.

    Supports:
    - Incremental extraction via watermark column
    - Chunked reads for memory-efficient large table extraction
    - Custom SQL queries
    """

    def __init__(self, config: dict):
        super().__init__(config)
        self.host = os.getenv("POSTGRES_HOST", config.get("host", "localhost"))
        self.port = int(os.getenv("POSTGRES_PORT", config.get("port", 5432)))
        self.db = os.getenv("POSTGRES_DB", config.get("database"))
        self.user = os.getenv("POSTGRES_USER", config.get("user"))
        self.password = os.getenv("POSTGRES_PASSWORD")
        self.table = config.get("table")
        self.query = config.get("query")
        self.watermark_col = config.get("watermark_column")
        self.watermark_value = config.get("watermark_value")
        self.chunk_size = config.get("chunk_size", 10_000)
        self._engine: Optional[sa.engine.Engine] = None

    def connect(self) -> None:
        dsn = f"postgresql+psycopg2://{self.user}:{self.password}@{self.host}:{self.port}/{self.db}"
        self._engine = sa.create_engine(dsn, pool_pre_ping=True)
        with self._engine.connect() as conn:
            conn.execute(sa.text("SELECT 1"))
        logger.info(f"[{self.source_name}] Connected to {self.host}/{self.db}")

    def extract(self) -> pd.DataFrame:
        sql = self._build_query()
        logger.info(f"[{self.source_name}] Running query: {sql[:120]}...")
        chunks = []
        with self._engine.connect() as conn:
            for chunk in pd.read_sql(sa.text(sql), conn, chunksize=self.chunk_size):
                chunks.append(chunk)
        return pd.concat(chunks, ignore_index=True) if chunks else pd.DataFrame()

    def _build_query(self) -> str:
        if self.query:
            return self.query
        sql = f"SELECT * FROM {self.table}"
        if self.watermark_col and self.watermark_value:
            sql += f" WHERE {self.watermark_col} > '{self.watermark_value}'"
        return sql

    def close(self) -> None:
        if self._engine:
            self._engine.dispose()
            self._engine = None
