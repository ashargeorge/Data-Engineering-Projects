"""Base loader interface."""

from abc import ABC, abstractmethod
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class BaseLoader(ABC):
    def __init__(self, config: dict):
        self.config = config
        self.loader_name = config.get("name", self.__class__.__name__)

    @abstractmethod
    def connect(self) -> None:
        """Establish connection to the destination."""

    @abstractmethod
    def load(self, df: pd.DataFrame) -> int:
        """Load the DataFrame. Returns number of rows written."""

    @abstractmethod
    def close(self) -> None:
        """Close the connection."""

    def run(self, df: pd.DataFrame) -> int:
        logger.info(f"[{self.loader_name}] Loading {len(df):,} rows")
        try:
            self.connect()
            rows_written = self.load(df)
            logger.info(f"[{self.loader_name}] Wrote {rows_written:,} rows successfully")
            return rows_written
        except Exception as e:
            logger.error(f"[{self.loader_name}] Load failed: {e}")
            raise
        finally:
            self.close()
