"""Snowflake loader: supports append, replace, and upsert write modes."""

import os
import logging
import pandas as pd
import sqlalchemy as sa
from typing import Optional, Literal
from etl.loaders.base import BaseLoader

logger = logging.getLogger(__name__)

WriteMode = Literal["append", "replace", "upsert"]


class SnowflakeLoader(BaseLoader):
    """
    Loads a DataFrame into Snowflake.

    Write modes:
    - append  : INSERT rows into existing table
    - replace : DROP + recreate table, then INSERT
    - upsert  : MERGE on primary key(s) — update existing, insert new

    Credentials are read from environment variables:
      SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER, SNOWFLAKE_PASSWORD,
      SNOWFLAKE_DATABASE, SNOWFLAKE_WAREHOUSE
    """

    def __init__(self, config: dict):
        super().__init__(config)
        self.schema = config.get("schema", "raw")
        self.table = config["table"]
        self.write_mode: WriteMode = config.get("write_mode", "append")
        self.primary_keys: list = config.get("primary_keys", [])
        self.batch_size: int = config.get("batch_size", 10_000)
        self._engine: Optional[sa.engine.Engine] = None

    def connect(self) -> None:
        account = os.environ["SNOWFLAKE_ACCOUNT"]
        user = os.environ["SNOWFLAKE_USER"]
        password = os.environ["SNOWFLAKE_PASSWORD"]
        database = os.environ["SNOWFLAKE_DATABASE"]
        warehouse = os.environ["SNOWFLAKE_WAREHOUSE"]

        dsn = (
            f"snowflake://{user}:{password}@{account}/"
            f"{database}/{self.schema}?warehouse={warehouse}"
        )
        self._engine = sa.create_engine(dsn)
        logger.info(f"[{self.loader_name}] Connected to Snowflake → {database}.{self.schema}.{self.table}")

    def load(self, df: pd.DataFrame) -> int:
        if self.write_mode == "upsert":
            return self._upsert(df)
        # 'append' or 'replace'
        if_exists = "append" if self.write_mode == "append" else "replace"
        df.to_sql(
            name=self.table,
            con=self._engine,
            schema=self.schema,
            if_exists=if_exists,
            index=False,
            chunksize=self.batch_size,
            method="multi",
        )
        return len(df)

    def _upsert(self, df: pd.DataFrame) -> int:
        """MERGE-based upsert using a staging table."""
        if not self.primary_keys:
            raise ValueError("primary_keys must be set for upsert write mode")

        staging_table = f"{self.table}_staging"

        # Write to staging
        df.to_sql(
            name=staging_table,
            con=self._engine,
            schema=self.schema,
            if_exists="replace",
            index=False,
            chunksize=self.batch_size,
            method="multi",
        )

        # Build MERGE statement
        join_clause = " AND ".join(
            f"target.{k} = source.{k}" for k in self.primary_keys
        )
        update_cols = [c for c in df.columns if c not in self.primary_keys]
        update_clause = ", ".join(f"target.{c} = source.{c}" for c in update_cols)
        insert_cols = ", ".join(df.columns)
        insert_vals = ", ".join(f"source.{c}" for c in df.columns)

        merge_sql = f"""
            MERGE INTO {self.schema}.{self.table} AS target
            USING {self.schema}.{staging_table} AS source
            ON {join_clause}
            WHEN MATCHED THEN UPDATE SET {update_clause}
            WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals})
        """

        with self._engine.begin() as conn:
            conn.execute(sa.text(merge_sql))
            conn.execute(sa.text(f"DROP TABLE IF EXISTS {self.schema}.{staging_table}"))

        return len(df)

    def close(self) -> None:
        if self._engine:
            self._engine.dispose()
            self._engine = None
