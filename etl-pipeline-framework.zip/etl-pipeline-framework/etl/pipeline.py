"""
Pipeline orchestrator: wires together extractor → validator → transformer → validator → loader.
Can be run standalone or invoked by the Airflow DAG.
"""

import argparse
import logging
import os
import sys
import time
from typing import Optional
import requests
import yaml
import pandas as pd

from etl.extractors.api_extractor import APIExtractor
from etl.extractors.csv_extractor import CSVExtractor
from etl.extractors.postgres_extractor import PostgresExtractor
from etl.transformers.sales_transformer import SalesTransformer
from etl.loaders.snowflake_loader import SnowflakeLoader
from etl.validators.data_validator import DataValidator, Severity

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

EXTRACTOR_MAP = {
    "api": APIExtractor,
    "csv": CSVExtractor,
    "postgres": PostgresExtractor,
}


def load_config(config_path: str) -> dict:
    with open(config_path) as f:
        return yaml.safe_load(f)


def build_post_extract_validator(config: dict) -> DataValidator:
    v = DataValidator(stage="post_extract", fail_on_critical=config["validation"].get("fail_on_critical", True))
    v.add_min_rows(1)
    return v


def build_post_transform_validator(config: dict) -> DataValidator:
    v = DataValidator(stage="post_transform", fail_on_critical=config["validation"].get("fail_on_critical", True))
    v.add_not_null("order_id")
    v.add_not_null("customer_id")
    v.add_not_null("amount")
    v.add_value_range("amount", min_val=0, severity=Severity.WARNING)
    v.add_allowed_values(
        "status",
        ["completed", "pending", "refunded", "cancelled", "unknown"],
        severity=Severity.WARNING,
    )
    return v


def send_slack_alert(webhook_url: str, pipeline_name: str, error: str) -> None:
    if not webhook_url:
        return
    payload = {
        "text": f":red_circle: *ETL Pipeline Failed*\n*Pipeline:* `{pipeline_name}`\n*Error:* {error}"
    }
    try:
        requests.post(webhook_url, json=payload, timeout=5)
    except Exception as e:
        logger.warning(f"Failed to send Slack alert: {e}")


def run_pipeline(config_path: str, source_override: Optional[str] = None) -> dict:
    config = load_config(config_path)
    pipeline_cfg = config["pipeline"]
    pipeline_name = pipeline_cfg["name"]
    slack_webhook = os.getenv("SLACK_WEBHOOK_URL", "")

    logger.info(f"=== Starting pipeline: {pipeline_name} ===")
    start_time = time.time()

    try:
        # Resolve source config
        sources = config["sources"]
        if source_override:
            sources = [s for s in sources if s["type"] == source_override]
        if not sources:
            raise ValueError(f"No source found for override: {source_override}")
        source_config = sources[0]

        extractor_cls = EXTRACTOR_MAP.get(source_config["type"])
        if not extractor_cls:
            raise ValueError(f"Unknown source type: {source_config['type']}")

        # Extract
        extractor = extractor_cls(source_config)
        raw_df = extractor.run()

        # Validate post-extract
        post_extract_validator = build_post_extract_validator(config)
        post_extract_validator.validate(raw_df)

        # Transform
        transformer = SalesTransformer(config={"name": pipeline_name})
        clean_df = transformer.run(raw_df)

        # Validate post-transform
        post_transform_validator = build_post_transform_validator(config)
        post_transform_validator.validate(clean_df)

        # Load
        dest_config = config["destinations"][0]
        loader = SnowflakeLoader(dest_config)
        rows_written = loader.run(clean_df)

        elapsed = time.time() - start_time
        result = {
            "status": "success",
            "pipeline": pipeline_name,
            "rows_extracted": len(raw_df),
            "rows_loaded": rows_written,
            "elapsed_seconds": round(elapsed, 2),
        }
        logger.info(f"=== Pipeline complete: {result} ===")
        return result

    except Exception as e:
        elapsed = time.time() - start_time
        logger.error(f"Pipeline failed after {elapsed:.1f}s: {e}", exc_info=True)
        send_slack_alert(slack_webhook, pipeline_name, str(e))
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run ETL pipeline")
    parser.add_argument("--config", required=True, help="Path to pipeline_config.yml")
    parser.add_argument("--source", help="Source type override (api|csv|postgres)")
    args = parser.parse_args()
    run_pipeline(args.config, args.source)
