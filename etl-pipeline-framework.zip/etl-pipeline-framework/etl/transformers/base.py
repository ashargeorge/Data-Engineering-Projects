"""Base transformer interface."""

from abc import ABC, abstractmethod
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class BaseTransformer(ABC):
    """
    Abstract base class for all data transformers.

    Transformers receive a raw DataFrame and return a cleaned,
    enriched, or restructured DataFrame.
    """

    def __init__(self, config: dict):
        self.config = config
        self.transformer_name = config.get("name", self.__class__.__name__)

    @abstractmethod
    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply transformations and return the result DataFrame."""

    def run(self, df: pd.DataFrame) -> pd.DataFrame:
        logger.info(f"[{self.transformer_name}] Transforming {len(df):,} rows")
        result = self.transform(df)
        logger.info(f"[{self.transformer_name}] Output: {len(result):,} rows, {len(result.columns)} columns")
        return result
