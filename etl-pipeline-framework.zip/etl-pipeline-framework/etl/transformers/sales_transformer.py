"""Sales data transformer: cleans, enriches, and standardises raw sales records."""

import logging
import pandas as pd
from etl.transformers.base import BaseTransformer

logger = logging.getLogger(__name__)


class SalesTransformer(BaseTransformer):
    """
    Transforms raw sales records into a clean, analytics-ready format.

    Steps:
    1. Standardise column names (snake_case)
    2. Parse and validate date fields
    3. Derive calculated fields (revenue, discount_pct)
    4. Normalise categorical fields
    5. Drop duplicates and filter invalid rows
    """

    REQUIRED_COLUMNS = {"order_id", "customer_id", "amount", "order_date", "status"}
    VALID_STATUSES = {"completed", "pending", "refunded", "cancelled"}

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df = self._standardise_columns(df)
        self._assert_required_columns(df)
        df = self._parse_dates(df)
        df = self._clean_amounts(df)
        df = self._normalise_status(df)
        df = self._derive_fields(df)
        df = self._drop_duplicates(df)
        df = self._filter_invalid_rows(df)
        return df

    def _standardise_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        df.columns = (
            df.columns
            .str.strip()
            .str.lower()
            .str.replace(r"[\s\-]+", "_", regex=True)
        )
        return df

    def _assert_required_columns(self, df: pd.DataFrame) -> None:
        missing = self.REQUIRED_COLUMNS - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

    def _parse_dates(self, df: pd.DataFrame) -> pd.DataFrame:
        df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
        df["order_year"] = df["order_date"].dt.year
        df["order_month"] = df["order_date"].dt.month
        df["order_quarter"] = df["order_date"].dt.quarter
        return df

    def _clean_amounts(self, df: pd.DataFrame) -> pd.DataFrame:
        df["amount"] = (
            df["amount"]
            .astype(str)
            .str.replace(r"[^\d\.\-]", "", regex=True)
            .pipe(pd.to_numeric, errors="coerce")
        )
        return df

    def _normalise_status(self, df: pd.DataFrame) -> pd.DataFrame:
        df["status"] = df["status"].str.strip().str.lower()
        unknown_mask = ~df["status"].isin(self.VALID_STATUSES)
        if unknown_mask.any():
            count = unknown_mask.sum()
            logger.warning(f"Setting {count} unknown status values to 'unknown'")
            df.loc[unknown_mask, "status"] = "unknown"
        return df

    def _derive_fields(self, df: pd.DataFrame) -> pd.DataFrame:
        df["discount_amount"] = df.get("original_price", df["amount"]) - df["amount"]
        df["discount_amount"] = df["discount_amount"].clip(lower=0)
        df["is_refunded"] = df["status"] == "refunded"
        df["is_completed"] = df["status"] == "completed"
        return df

    def _drop_duplicates(self, df: pd.DataFrame) -> pd.DataFrame:
        before = len(df)
        df = df.drop_duplicates(subset=["order_id"])
        dropped = before - len(df)
        if dropped:
            logger.warning(f"Dropped {dropped} duplicate order_id rows")
        return df

    def _filter_invalid_rows(self, df: pd.DataFrame) -> pd.DataFrame:
        valid_mask = (
            df["order_id"].notna() &
            df["customer_id"].notna() &
            df["amount"].notna() &
            df["order_date"].notna()
        )
        invalid_count = (~valid_mask).sum()
        if invalid_count:
            logger.warning(f"Filtered {invalid_count} rows with null required fields")
        return df[valid_mask].reset_index(drop=True)
