"""Data quality validator: runs rule-based checks and emits structured reports."""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, List, Optional
import pandas as pd

logger = logging.getLogger(__name__)


class Severity(str, Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


@dataclass
class ValidationRule:
    name: str
    check: Callable[[pd.DataFrame], bool]
    message: str
    severity: Severity = Severity.CRITICAL


@dataclass
class ValidationResult:
    rule_name: str
    passed: bool
    severity: Severity
    message: str
    detail: Optional[str] = None


@dataclass
class ValidationReport:
    stage: str
    results: List[ValidationResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(r.passed for r in self.results if r.severity == Severity.CRITICAL)

    @property
    def summary(self) -> str:
        total = len(self.results)
        failed = sum(1 for r in self.results if not r.passed)
        status = "PASSED" if self.passed else "FAILED"
        return f"[{self.stage}] Validation {status}: {total - failed}/{total} checks passed"


class DataValidator:
    """
    Runs a suite of validation rules against a DataFrame and
    produces a structured ValidationReport.

    Usage:
        validator = DataValidator(stage="post_extract")
        validator.add_rule(ValidationRule(
            name="no_nulls_in_order_id",
            check=lambda df: df["order_id"].notna().all(),
            message="order_id must not contain nulls",
            severity=Severity.CRITICAL,
        ))
        report = validator.validate(df)
        if not report.passed:
            raise ValueError(report.summary)
    """

    def __init__(self, stage: str, fail_on_critical: bool = True):
        self.stage = stage
        self.fail_on_critical = fail_on_critical
        self._rules: List[ValidationRule] = []

    def add_rule(self, rule: ValidationRule) -> "DataValidator":
        self._rules.append(rule)
        return self

    def add_not_null(self, column: str, severity: Severity = Severity.CRITICAL) -> "DataValidator":
        return self.add_rule(ValidationRule(
            name=f"{column}_not_null",
            check=lambda df, c=column: df[c].notna().all(),
            message=f"Column '{column}' must not contain nulls",
            severity=severity,
        ))

    def add_min_rows(self, min_rows: int, severity: Severity = Severity.CRITICAL) -> "DataValidator":
        return self.add_rule(ValidationRule(
            name="min_row_count",
            check=lambda df: len(df) >= min_rows,
            message=f"DataFrame must have at least {min_rows} rows",
            severity=severity,
        ))

    def add_unique(self, column: str, severity: Severity = Severity.CRITICAL) -> "DataValidator":
        return self.add_rule(ValidationRule(
            name=f"{column}_unique",
            check=lambda df, c=column: df[c].is_unique,
            message=f"Column '{column}' must be unique",
            severity=severity,
        ))

    def add_value_range(
        self, column: str, min_val=None, max_val=None, severity: Severity = Severity.WARNING
    ) -> "DataValidator":
        def check(df, c=column, lo=min_val, hi=max_val):
            series = df[c].dropna()
            if lo is not None and (series < lo).any():
                return False
            if hi is not None and (series > hi).any():
                return False
            return True
        return self.add_rule(ValidationRule(
            name=f"{column}_range",
            check=check,
            message=f"Column '{column}' values must be in [{min_val}, {max_val}]",
            severity=severity,
        ))

    def add_allowed_values(
        self, column: str, allowed: list, severity: Severity = Severity.WARNING
    ) -> "DataValidator":
        return self.add_rule(ValidationRule(
            name=f"{column}_allowed_values",
            check=lambda df, c=column, a=allowed: df[c].isin(a).all(),
            message=f"Column '{column}' contains values not in allowed set: {allowed}",
            severity=severity,
        ))

    def validate(self, df: pd.DataFrame) -> ValidationReport:
        report = ValidationReport(stage=self.stage)
        for rule in self._rules:
            try:
                passed = bool(rule.check(df))
                detail = None
            except Exception as e:
                passed = False
                detail = f"Rule raised an exception: {e}"

            result = ValidationResult(
                rule_name=rule.name,
                passed=passed,
                severity=rule.severity,
                message=rule.message,
                detail=detail,
            )
            report.results.append(result)

            level = logging.DEBUG if passed else (
                logging.ERROR if rule.severity == Severity.CRITICAL else logging.WARNING
            )
            status = "✓" if passed else "✗"
            logger.log(level, f"  {status} [{rule.severity.value.upper()}] {rule.name}")
            if not passed and detail:
                logger.log(level, f"    Detail: {detail}")

        logger.info(report.summary)

        if self.fail_on_critical and not report.passed:
            raise ValueError(report.summary)

        return report
