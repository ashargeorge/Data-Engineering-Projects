"""
REST API Extractor.

Handles paginated JSON REST APIs with configurable auth,
retry logic, and rate-limit backoff.
"""

import time
import requests
import pandas as pd
from typing import Optional
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from src.extractors.base import BaseExtractor, ExtractionError


class ApiExtractor(BaseExtractor):
    """
    Extracts data from paginated REST APIs.

    Config keys:
        endpoint (str): Base URL of the API.
        auth_token_env (str): Env var name holding the Bearer token.
        page_size (int): Records per page. Default 100.
        max_pages (int): Safety cap on pagination. Default 50.
        timeout (int): Request timeout in seconds. Default 30.
        params (dict): Extra query parameters merged into every request.
    """

    DEFAULT_PAGE_SIZE = 100
    DEFAULT_MAX_PAGES = 50
    DEFAULT_TIMEOUT = 30

    def __init__(self, source_name: str, config: dict):
        super().__init__(source_name, config)
        self.endpoint = config["endpoint"]
        self.page_size = config.get("page_size", self.DEFAULT_PAGE_SIZE)
        self.max_pages = config.get("max_pages", self.DEFAULT_MAX_PAGES)
        self.timeout = config.get("timeout", self.DEFAULT_TIMEOUT)
        self.extra_params = config.get("params", {})
        self._token = self._load_token(config.get("auth_token_env"))
        self._session = self._build_session()

    def _load_token(self, env_var: Optional[str]) -> Optional[str]:
        if not env_var:
            return None
        import os
        token = os.getenv(env_var)
        if not token:
            self.logger.warning(
                f"Auth token env var '{env_var}' is not set. "
                "Proceeding without authentication."
            )
        return token

    def _build_session(self) -> requests.Session:
        """Build a session with automatic retries on transient errors."""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=1.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"],
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)

        if self._token:
            session.headers.update({"Authorization": f"Bearer {self._token}"})

        return session

    def validate_connection(self) -> bool:
        try:
            resp = self._session.get(self.endpoint, timeout=5)
            return resp.status_code < 500
        except requests.RequestException as exc:
            self.logger.error(f"Connection check failed: {exc}")
            return False

    def extract(self) -> pd.DataFrame:
        records = []
        page = 1

        while page <= self.max_pages:
            params = {
                "page": page,
                "page_size": self.page_size,
                **self.extra_params,
            }

            self.logger.debug(f"Fetching page {page} from {self.endpoint}")
            try:
                resp = self._session.get(
                    self.endpoint, params=params, timeout=self.timeout
                )
                resp.raise_for_status()
            except requests.HTTPError as exc:
                raise ExtractionError(
                    f"API request failed on page {page}: {exc}"
                ) from exc

            payload = resp.json()

            # Support common pagination envelope shapes
            if isinstance(payload, list):
                batch = payload
            elif isinstance(payload, dict):
                batch = payload.get("data") or payload.get("results") or payload.get("items") or []
            else:
                raise ExtractionError(f"Unexpected API response shape: {type(payload)}")

            if not batch:
                self.logger.debug(f"Empty page {page} — pagination complete.")
                break

            records.extend(batch)
            self.logger.info(f"Page {page}: {len(batch)} records (total so far: {len(records)})")

            # Respect rate limits if the API signals them
            remaining = resp.headers.get("X-RateLimit-Remaining")
            if remaining and int(remaining) < 5:
                self.logger.warning("Rate limit approaching — sleeping 2s.")
                time.sleep(2)

            page += 1

        if not records:
            self.logger.warning(f"No records returned from {self.endpoint}.")
            return pd.DataFrame()

        return pd.DataFrame(records)
