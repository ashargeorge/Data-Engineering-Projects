"""
Base extractor interface.

All extractors must implement this contract. The DAG factory
discovers and instantiates extractors based on pipeline_config.yaml.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import logging
import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class ExtractorResult:
    """Standardised result envelope returned by every extractor."""
    data: pd.DataFrame
    source_name: str
    extracted_at: datetime = field(default_factory=datetime.utcnow)
    row_count: int = 0
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        self.row_count = len(self.data)


class BaseExtractor(ABC):
    """
    Abstract base class for all ETL extractors.

    Subclasses implement `extract()` and optionally override
    `validate_connection()` for pre-flight checks.
    """

    def __init__(self, source_name: str, config: dict):
        self.source_name = source_name
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)

    @abstractmethod
    def extract(self) -> pd.DataFrame:
        """
        Pull data from the source and return a raw DataFrame.

        Returns:
            pd.DataFrame: Raw, unprocessed data from the source.

        Raises:
            ExtractionError: If the source is unreachable or returns bad data.
        """

    @abstractmethod
    def validate_connection(self) -> bool:
        """
        Test connectivity to the source before extraction begins.

        Returns:
            bool: True if the connection is healthy, False otherwise.
        """

    def run(self) -> ExtractorResult:
        """
        Orchestrated entry point called by the DAG.
        Wraps extract() with logging, timing, and error handling.
        """
        self.logger.info(f"[{self.source_name}] Starting extraction...")
        start = datetime.utcnow()

        if not self.validate_connection():
            raise ConnectionError(
                f"[{self.source_name}] Connection validation failed. "
                "Check your credentials and network access."
            )

        df = self.extract()

        elapsed = (datetime.utcnow() - start).total_seconds()
        self.logger.info(
            f"[{self.source_name}] Extraction complete — "
            f"{len(df):,} rows in {elapsed:.2f}s"
        )

        return ExtractorResult(
            data=df,
            source_name=self.source_name,
            metadata={"elapsed_seconds": elapsed},
        )


class ExtractionError(Exception):
    """Raised when an extractor cannot retrieve data from its source."""
