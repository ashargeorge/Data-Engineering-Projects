"""Unit tests for SalesTransformer."""

import pandas as pd
import pytest
from etl.transformers.sales_transformer import SalesTransformer


@pytest.fixture
def transformer():
    return SalesTransformer(config={"name": "test"})


@pytest.fixture
def valid_df():
    return pd.DataFrame({
        "order_id": ["O001", "O002", "O003"],
        "customer_id": ["C1", "C2", "C3"],
        "amount": ["100.00", "$200.50", "300"],
        "order_date": ["2024-01-15", "2024-02-20", "2024-03-10"],
        "status": ["Completed", "PENDING", "refunded"],
    })


def test_transform_returns_dataframe(transformer, valid_df):
    result = transformer.run(valid_df)
    assert isinstance(result, pd.DataFrame)


def test_column_names_snake_case(transformer, valid_df):
    result = transformer.run(valid_df)
    for col in result.columns:
        assert col == col.lower(), f"Column '{col}' is not snake_case"


def test_status_normalised_to_lowercase(transformer, valid_df):
    result = transformer.run(valid_df)
    assert result["status"].str.islower().all()


def test_amount_parsed_to_numeric(transformer, valid_df):
    result = transformer.run(valid_df)
    assert pd.api.types.is_numeric_dtype(result["amount"])


def test_order_date_parsed_to_datetime(transformer, valid_df):
    result = transformer.run(valid_df)
    assert pd.api.types.is_datetime64_any_dtype(result["order_date"])


def test_derived_columns_exist(transformer, valid_df):
    result = transformer.run(valid_df)
    assert "is_refunded" in result.columns
    assert "is_completed" in result.columns
    assert "order_year" in result.columns


def test_is_refunded_correct(transformer, valid_df):
    result = transformer.run(valid_df)
    refunded_row = result[result["order_id"] == "O003"]
    assert refunded_row["is_refunded"].values[0] is True


def test_duplicates_dropped(transformer):
    df = pd.DataFrame({
        "order_id": ["O001", "O001", "O002"],
        "customer_id": ["C1", "C1", "C2"],
        "amount": [100, 100, 200],
        "order_date": ["2024-01-01"] * 3,
        "status": ["completed"] * 3,
    })
    result = transformer.run(df)
    assert len(result) == 2


def test_rows_with_null_order_id_filtered(transformer):
    df = pd.DataFrame({
        "order_id": ["O001", None],
        "customer_id": ["C1", "C2"],
        "amount": [100, 200],
        "order_date": ["2024-01-01", "2024-01-02"],
        "status": ["completed", "pending"],
    })
    result = transformer.run(df)
    assert len(result) == 1
    assert result["order_id"].notna().all()


def test_missing_required_column_raises(transformer):
    df = pd.DataFrame({"order_id": ["O001"], "amount": [100]})
    with pytest.raises(ValueError, match="Missing required columns"):
        transformer.run(df)
