"""Unit tests for DataValidator."""

import pandas as pd
import pytest
from etl.validators.data_validator import DataValidator, ValidationRule, Severity


@pytest.fixture
def sample_df():
    return pd.DataFrame({
        "id": [1, 2, 3],
        "name": ["Alice", "Bob", "Carol"],
        "amount": [100.0, 200.0, 300.0],
        "status": ["active", "inactive", "active"],
    })


def test_validator_passes_on_valid_data(sample_df):
    v = DataValidator(stage="test", fail_on_critical=True)
    v.add_min_rows(1)
    v.add_not_null("id")
    report = v.validate(sample_df)
    assert report.passed


def test_not_null_fails_on_null_column():
    df = pd.DataFrame({"id": [1, None, 3]})
    v = DataValidator(stage="test", fail_on_critical=True)
    v.add_not_null("id")
    with pytest.raises(ValueError):
        v.validate(df)


def test_min_rows_fails_on_empty_dataframe():
    df = pd.DataFrame({"id": []})
    v = DataValidator(stage="test", fail_on_critical=True)
    v.add_min_rows(1)
    with pytest.raises(ValueError):
        v.validate(df)


def test_unique_fails_on_duplicates():
    df = pd.DataFrame({"id": [1, 1, 2]})
    v = DataValidator(stage="test", fail_on_critical=True)
    v.add_unique("id")
    with pytest.raises(ValueError):
        v.validate(df)


def test_value_range_warning_does_not_raise(sample_df):
    df = sample_df.copy()
    df.loc[0, "amount"] = -10
    v = DataValidator(stage="test", fail_on_critical=True)
    v.add_value_range("amount", min_val=0, severity=Severity.WARNING)
    report = v.validate(df)
    # Should pass (critical) even though a WARNING check failed
    assert report.passed
    assert any(not r.passed for r in report.results)


def test_allowed_values_check(sample_df):
    v = DataValidator(stage="test", fail_on_critical=False)
    v.add_allowed_values("status", ["active", "inactive"], severity=Severity.WARNING)
    report = v.validate(sample_df)
    assert all(r.passed for r in report.results)


def test_custom_rule(sample_df):
    v = DataValidator(stage="test", fail_on_critical=True)
    v.add_rule(ValidationRule(
        name="amount_sum_positive",
        check=lambda df: df["amount"].sum() > 0,
        message="Total amount must be positive",
        severity=Severity.CRITICAL,
    ))
    report = v.validate(sample_df)
    assert report.passed


def test_report_summary_contains_stage():
    df = pd.DataFrame({"id": [1]})
    v = DataValidator(stage="my_stage", fail_on_critical=False)
    v.add_min_rows(1)
    report = v.validate(df)
    assert "my_stage" in report.summary
