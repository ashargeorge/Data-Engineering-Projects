# Real-Time Streaming Pipeline — Kafka + PySpark + BigQuery

An end-to-end streaming data pipeline that ingests real-time e-commerce clickstream events from **Apache Kafka**, processes them with **PySpark Structured Streaming**, and writes aggregated metrics to **Google BigQuery** — served by a live **Grafana** dashboard.

---

## Architecture

```
[Event Producer]
  Python script simulating
  10k+ events/min (clicks,
  add-to-cart, purchases)
       │
       ▼
[Apache Kafka]
  Topic: clickstream-events
  Schema Registry validation
  Dead-letter queue (DLQ)
       │
       ▼
[PySpark Structured Streaming]
  Windowed aggregations
  Watermarking for late data
  Session detection
       │
       ▼
[Google BigQuery]
  raw.clickstream_events
  marts.session_metrics
  marts.product_metrics
       │
       ▼
[Grafana Dashboard]
  Live session counts
  Conversion funnel
  Revenue per minute
  Pipeline latency
```

---

## Features

- **Kafka producer** simulating realistic clickstream events at configurable throughput
- **Schema Registry** integration with Avro schema enforcement
- **Dead-letter queue** for malformed or schema-violating events
- **PySpark Structured Streaming** with 1-minute tumbling windows and 10-minute watermarks
- **Exactly-once semantics** via Kafka transactions + BigQuery streaming insert dedup
- **Live Grafana dashboard** — sessions, conversions, revenue, latency
- **Terraform** scripts for full GCP infrastructure provisioning
- **Comprehensive test suite** for producer, transformations, and aggregations

---

## Project Structure

```
streaming-pipeline-kafka-spark/
├── producer/
│   ├── event_producer.py       # Kafka event producer (simulated clickstream)
│   ├── event_models.py         # Pydantic event schemas
│   └── event_generator.py      # Realistic fake event data generator
├── consumer/
│   └── dlq_consumer.py         # Dead-letter queue consumer & reporter
├── spark/
│   ├── streaming_job.py        # Main PySpark Structured Streaming job
│   ├── transformations.py      # Stateless + stateful transformations
│   └── bigquery_sink.py        # BigQuery write stream helper
├── schemas/
│   ├── clickstream_event.avsc  # Avro schema for Kafka messages
│   └── schema_registry.py      # Schema Registry client wrapper
├── grafana/
│   └── dashboards/
│       └── clickstream.json    # Grafana dashboard definition
├── terraform/
│   ├── main.tf                 # GCP resources: BigQuery, Pub/Sub, GKE
│   ├── variables.tf
│   └── outputs.tf
├── tests/
│   ├── test_event_generator.py
│   ├── test_transformations.py
│   └── test_dlq_consumer.py
├── config/
│   └── pipeline_config.yml
├── scripts/
│   ├── start_local.sh          # Start Kafka + Spark locally
│   └── seed_topics.sh          # Create Kafka topics
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

---

## Quickstart

### 1. Clone and configure

```bash
git clone https://github.com/your-username/streaming-pipeline-kafka-spark.git
cd streaming-pipeline-kafka-spark
cp .env.example .env
# Add your GCP project ID and credentials path
```

### 2. Start local infrastructure

```bash
docker-compose up -d
# Wait ~30s for Kafka and Schema Registry to be ready
bash scripts/seed_topics.sh
```

### 3. Start the Spark streaming job

```bash
pip install -r requirements.txt
spark-submit \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0,\
com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.36.1 \
  spark/streaming_job.py --config config/pipeline_config.yml
```

### 4. Start the event producer

```bash
python producer/event_producer.py --rate 200 --duration 300
# Produces 200 events/sec for 5 minutes
```

### 5. View the dashboard

Open Grafana at `http://localhost:3000` (admin / admin).
Import `grafana/dashboards/clickstream.json`.

---

## GCP Infrastructure (Terraform)

```bash
cd terraform
terraform init
terraform plan -var="project_id=your-gcp-project"
terraform apply
```

Creates: BigQuery dataset + tables, GCS bucket for Spark checkpoints, IAM service account with least-privilege roles.

---

## Environment Variables

| Variable | Description |
|---|---|
| `KAFKA_BOOTSTRAP_SERVERS` | Kafka broker(s), e.g. `localhost:9092` |
| `KAFKA_TOPIC` | Source topic name (default: `clickstream-events`) |
| `KAFKA_DLQ_TOPIC` | Dead-letter topic (default: `clickstream-dlq`) |
| `SCHEMA_REGISTRY_URL` | Schema Registry URL |
| `GCP_PROJECT_ID` | GCP project ID |
| `BIGQUERY_DATASET` | Target BigQuery dataset |
| `GCS_CHECKPOINT_BUCKET` | GCS bucket for Spark checkpoints |
| `GOOGLE_APPLICATION_CREDENTIALS` | Path to GCP service account JSON |

---

## Event Schema

```json
{
  "event_id": "uuid4",
  "user_id": "string",
  "session_id": "string",
  "event_type": "page_view | product_view | add_to_cart | checkout | purchase",
  "product_id": "string | null",
  "product_category": "string | null",
  "amount": "float | null",
  "page_url": "string",
  "device_type": "mobile | desktop | tablet",
  "country": "string",
  "timestamp": "ISO 8601"
}
```

---

## License

MIT
