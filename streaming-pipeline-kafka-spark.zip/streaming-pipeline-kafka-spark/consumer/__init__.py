"""Streaming pipeline package"""
