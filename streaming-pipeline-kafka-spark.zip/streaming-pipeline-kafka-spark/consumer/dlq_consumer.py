"""
Dead-letter queue consumer.
Polls the DLQ topic, logs errors, and writes a summary report.
"""

import json
import logging
import os
import signal
import time
from collections import Counter
from datetime import datetime
from threading import Event

from confluent_kafka import Consumer, KafkaError

logger = logging.getLogger(__name__)
shutdown_event = Event()
signal.signal(signal.SIGINT,  lambda *_: shutdown_event.set())
signal.signal(signal.SIGTERM, lambda *_: shutdown_event.set())


class DLQConsumer:
    """
    Consumes messages from the dead-letter queue topic,
    tracks error patterns, and emits periodic reports.
    """

    def __init__(self, config: dict):
        self.dlq_topic   = os.getenv("KAFKA_DLQ_TOPIC", config["kafka"]["dlq_topic"])
        self.report_path = config.get("dlq", {}).get("report_path", "/tmp/dlq_report.json")
        self._messages   = []
        self._errors     = Counter()

        kafka_conf = {
            "bootstrap.servers": os.getenv(
                "KAFKA_BOOTSTRAP_SERVERS",
                config["kafka"]["bootstrap_servers"],
            ),
            "group.id":          "dlq-consumer",
            "auto.offset.reset": "earliest",
            "enable.auto.commit": True,
        }
        self._consumer = Consumer(kafka_conf)
        self._consumer.subscribe([self.dlq_topic])
        logger.info(f"DLQ consumer subscribed to: {self.dlq_topic}")

    def consume(self, max_messages: int = None, timeout: float = 60.0) -> list:
        """Consume DLQ messages until timeout or max_messages reached."""
        start   = time.time()
        results = []

        while not shutdown_event.is_set():
            if max_messages and len(results) >= max_messages:
                break
            if time.time() - start > timeout:
                break

            msg = self._consumer.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                if msg.error().code() != KafkaError._PARTITION_EOF:
                    logger.error(f"Kafka error: {msg.error()}")
                continue

            try:
                payload = json.loads(msg.value().decode("utf-8"))
                reason  = payload.get("error_reason", "unknown")
                self._errors[reason] += 1
                self._messages.append(payload)
                results.append(payload)
                logger.debug(f"DLQ message: reason={reason}")
            except json.JSONDecodeError as e:
                logger.error(f"Could not parse DLQ message: {e}")
                self._errors["json_decode_error"] += 1

        return results

    def write_report(self) -> dict:
        report = {
            "generated_at":  datetime.utcnow().isoformat(),
            "total_dlq":     len(self._messages),
            "error_counts":  dict(self._errors.most_common()),
            "sample_errors": self._messages[:10],
        }
        with open(self.report_path, "w") as f:
            json.dump(report, f, indent=2, default=str)
        logger.info(f"DLQ report written to {self.report_path}")
        return report

    def close(self) -> None:
        self._consumer.close()


def main(config_path: str = "config/pipeline_config.yml"):
    import yaml
    with open(config_path) as f:
        config = yaml.safe_load(f)

    consumer = DLQConsumer(config)
    try:
        consumer.consume(timeout=3600)   # Run for 1 hour then report
    finally:
        report = consumer.write_report()
        logger.info(f"DLQ summary: {report['total_dlq']} messages, errors: {report['error_counts']}")
        consumer.close()


if __name__ == "__main__":
    main()
