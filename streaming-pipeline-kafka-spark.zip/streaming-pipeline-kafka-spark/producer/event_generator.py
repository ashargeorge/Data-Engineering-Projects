"""Generates realistic fake clickstream events using weighted distributions."""

import random
import uuid
from datetime import datetime
from typing import List
from producer.event_models import ClickstreamEvent, EventType, DeviceType

# Realistic product catalogue
PRODUCTS = [
    ("P001", "Electronics"),  ("P002", "Electronics"),  ("P003", "Electronics"),
    ("P004", "Clothing"),     ("P005", "Clothing"),      ("P006", "Clothing"),
    ("P007", "Home & Garden"),("P008", "Home & Garden"), ("P009", "Sports"),
    ("P010", "Sports"),       ("P011", "Beauty"),        ("P012", "Beauty"),
]

COUNTRIES = [
    ("NG", 0.20), ("US", 0.18), ("GB", 0.10), ("IN", 0.12),
    ("DE", 0.08), ("FR", 0.07), ("BR", 0.07), ("CA", 0.05),
    ("AU", 0.05), ("ZA", 0.04), ("KE", 0.04),
]

PAGES = [
    "/", "/products", "/products/{id}", "/cart",
    "/checkout", "/account", "/search", "/deals",
]

DEVICE_WEIGHTS = [
    (DeviceType.MOBILE, 0.58),
    (DeviceType.DESKTOP, 0.34),
    (DeviceType.TABLET, 0.08),
]

# Funnel transition probabilities: what event follows each event type
FUNNEL_TRANSITIONS = {
    EventType.PAGE_VIEW:    [(EventType.PAGE_VIEW, 0.40), (EventType.PRODUCT_VIEW, 0.45), (EventType.ADD_TO_CART, 0.10), (None, 0.05)],
    EventType.PRODUCT_VIEW: [(EventType.PRODUCT_VIEW, 0.30), (EventType.ADD_TO_CART, 0.35), (EventType.PAGE_VIEW, 0.25), (None, 0.10)],
    EventType.ADD_TO_CART:  [(EventType.CHECKOUT, 0.45), (EventType.PAGE_VIEW, 0.25), (EventType.PRODUCT_VIEW, 0.20), (None, 0.10)],
    EventType.CHECKOUT:     [(EventType.PURCHASE, 0.65), (EventType.ADD_TO_CART, 0.20), (None, 0.15)],
    EventType.PURCHASE:     [(EventType.PAGE_VIEW, 0.50), (None, 0.50)],
}

PRICE_RANGES = {
    "Electronics":   (49.99,  1299.99),
    "Clothing":      (9.99,   199.99),
    "Home & Garden": (14.99,  499.99),
    "Sports":        (19.99,  399.99),
    "Beauty":        (7.99,   149.99),
}


def _weighted_choice(choices):
    """Pick from (value, weight) pairs."""
    values, weights = zip(*choices)
    return random.choices(values, weights=weights, k=1)[0]


def generate_session_events(
    session_id: str = None,
    user_id: str = None,
    min_events: int = 2,
    max_events: int = 15,
) -> List[ClickstreamEvent]:
    """
    Generate a realistic sequence of events for a single user session.
    Follows funnel transition probabilities so the event stream looks authentic.
    """
    session_id = session_id or str(uuid.uuid4())
    user_id    = user_id    or str(uuid.uuid4())[:8]
    country    = _weighted_choice(COUNTRIES)
    device     = _weighted_choice(DEVICE_WEIGHTS)
    product_id, category = random.choice(PRODUCTS)
    price_lo, price_hi   = PRICE_RANGES[category]

    events: List[ClickstreamEvent] = []
    current_event_type = EventType.PAGE_VIEW
    n_events = random.randint(min_events, max_events)

    for _ in range(n_events):
        is_product_event = current_event_type in (
            EventType.PRODUCT_VIEW, EventType.ADD_TO_CART,
            EventType.CHECKOUT, EventType.PURCHASE,
        )
        amount = None
        if current_event_type == EventType.PURCHASE:
            amount = round(random.uniform(price_lo, price_hi), 2)

        event = ClickstreamEvent(
            user_id=user_id,
            session_id=session_id,
            event_type=current_event_type,
            product_id=product_id if is_product_event else None,
            product_category=category if is_product_event else None,
            amount=amount,
            page_url=random.choice(PAGES).replace("{id}", product_id),
            device_type=device,
            country=country,
            timestamp=datetime.utcnow(),
        )
        events.append(event)

        next_type = _weighted_choice(FUNNEL_TRANSITIONS[current_event_type])
        if next_type is None:
            break
        current_event_type = next_type

    return events


def generate_single_event() -> ClickstreamEvent:
    """Generate one random event (used for high-throughput injection)."""
    return generate_session_events(min_events=1, max_events=1)[0]
