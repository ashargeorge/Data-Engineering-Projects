"""Pydantic models for clickstream events with validation."""

from __future__ import annotations
import uuid
from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator


class EventType(str, Enum):
    PAGE_VIEW     = "page_view"
    PRODUCT_VIEW  = "product_view"
    ADD_TO_CART   = "add_to_cart"
    CHECKOUT      = "checkout"
    PURCHASE      = "purchase"


class DeviceType(str, Enum):
    MOBILE  = "mobile"
    DESKTOP = "desktop"
    TABLET  = "tablet"


class ClickstreamEvent(BaseModel):
    """
    A single user interaction event in the clickstream.
    Used for Kafka serialisation and schema validation.
    """
    event_id:         str            = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:          str
    session_id:       str
    event_type:       EventType
    product_id:       Optional[str]   = None
    product_category: Optional[str]   = None
    amount:           Optional[float] = None
    page_url:         str
    device_type:      DeviceType
    country:          str
    timestamp:        datetime        = Field(default_factory=datetime.utcnow)

    @field_validator("amount")
    @classmethod
    def amount_non_negative(cls, v):
        if v is not None and v < 0:
            raise ValueError(f"amount must be non-negative, got {v}")
        return v

    @field_validator("user_id", "session_id")
    @classmethod
    def ids_not_empty(cls, v):
        if not v.strip():
            raise ValueError("ID fields must not be empty")
        return v.strip()

    def to_kafka_dict(self) -> dict:
        d = self.model_dump()
        d["timestamp"]   = self.timestamp.isoformat()
        d["event_type"]  = self.event_type.value
        d["device_type"] = self.device_type.value
        return d


class SessionMetrics(BaseModel):
    session_id:    str
    user_id:       str
    window_start:  datetime
    window_end:    datetime
    event_count:   int
    page_views:    int
    product_views: int
    add_to_carts:  int
    purchases:     int
    total_revenue: float
    device_type:   str
    country:       str
    converted:     bool


class ProductMetrics(BaseModel):
    product_id:       str
    product_category: str
    window_start:     datetime
    window_end:       datetime
    views:            int
    add_to_carts:     int
    purchases:        int
    total_revenue:    float
    conversion_rate:  float
