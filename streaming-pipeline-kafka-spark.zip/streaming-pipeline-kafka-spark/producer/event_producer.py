"""
Kafka event producer — simulates a live e-commerce clickstream.

Usage:
    python producer/event_producer.py --rate 200 --duration 300
    python producer/event_producer.py --rate 500 --duration 60 --mode burst
"""

import argparse
import json
import logging
import os
import signal
import sys
import time
from threading import Event
from typing import Optional

from confluent_kafka import Producer, KafkaException
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer
from confluent_kafka.serialization import SerializationContext, MessageField

from producer.event_generator import generate_session_events, generate_single_event
from producer.event_models import ClickstreamEvent

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

# Graceful shutdown
shutdown_event = Event()
signal.signal(signal.SIGINT,  lambda *_: shutdown_event.set())
signal.signal(signal.SIGTERM, lambda *_: shutdown_event.set())


class ClickstreamProducer:
    """
    Wraps confluent-kafka Producer with:
    - Avro schema serialisation via Schema Registry
    - Delivery callback reporting
    - Dead-letter routing for serialisation failures
    - Per-second throughput metrics
    """

    def __init__(self, config: dict):
        self.topic     = config["kafka"]["topic"]
        self.dlq_topic = config["kafka"]["dlq_topic"]
        self._sent     = 0
        self._errors   = 0
        self._dlq_sent = 0

        # Kafka producer
        kafka_conf = {
            "bootstrap.servers": os.getenv(
                "KAFKA_BOOTSTRAP_SERVERS",
                config["kafka"]["bootstrap_servers"],
            ),
            "acks": "all",
            "enable.idempotence": True,
            "compression.type": "lz4",
            "linger.ms": 5,
            "batch.size": 65536,
        }
        self._producer = Producer(kafka_conf)

        # Schema Registry
        sr_url = os.getenv("SCHEMA_REGISTRY_URL", config["schema_registry"]["url"])
        sr_conf = {"url": sr_url}
        self._sr_client = SchemaRegistryClient(sr_conf)
        logger.info(f"Producer initialised → topic={self.topic}")

    def _delivery_callback(self, err, msg):
        if err:
            logger.error(f"Delivery failed for offset {msg.offset()}: {err}")
            self._errors += 1
        else:
            self._sent += 1

    def send(self, event: ClickstreamEvent) -> None:
        try:
            value = json.dumps(event.to_kafka_dict()).encode("utf-8")
            self._producer.produce(
                topic=self.topic,
                key=event.session_id.encode("utf-8"),
                value=value,
                on_delivery=self._delivery_callback,
            )
            self._producer.poll(0)  # Trigger callbacks without blocking
        except (KafkaException, Exception) as e:
            logger.warning(f"Serialisation error, routing to DLQ: {e}")
            self._send_dlq(event, str(e))

    def _send_dlq(self, event: ClickstreamEvent, reason: str) -> None:
        dlq_payload = {
            "original_event": event.to_kafka_dict(),
            "error_reason": reason,
            "dlq_timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        self._producer.produce(
            topic=self.dlq_topic,
            key=event.event_id.encode("utf-8"),
            value=json.dumps(dlq_payload).encode("utf-8"),
        )
        self._dlq_sent += 1

    def flush(self) -> None:
        remaining = self._producer.flush(timeout=10)
        if remaining:
            logger.warning(f"{remaining} messages not delivered after flush")

    @property
    def stats(self) -> dict:
        return {
            "sent": self._sent,
            "errors": self._errors,
            "dlq_sent": self._dlq_sent,
        }


def run(rate: int, duration: Optional[int], mode: str, config: dict) -> None:
    """
    Main producer loop.

    Modes:
    - steady : constant `rate` events per second
    - burst  : alternates between high and low throughput every 30s
    - session: produces realistic multi-event sessions
    """
    producer = ClickstreamProducer(config)
    interval = 1.0 / rate
    start    = time.time()
    last_log = start
    total    = 0

    logger.info(f"Starting producer | mode={mode} rate={rate}/s duration={duration}s")

    while not shutdown_event.is_set():
        if duration and (time.time() - start) >= duration:
            break

        tick = time.time()

        if mode == "session":
            events = generate_session_events()
            for event in events:
                producer.send(event)
                total += 1
        else:
            current_rate = rate
            if mode == "burst":
                elapsed_cycle = int(time.time() - start) % 60
                current_rate  = rate * 3 if elapsed_cycle < 30 else max(10, rate // 3)
                interval      = 1.0 / current_rate

            producer.send(generate_single_event())
            total += 1

        # Throttle to target rate
        elapsed = time.time() - tick
        sleep   = interval - elapsed
        if sleep > 0:
            time.sleep(sleep)

        # Log stats every 10 seconds
        if time.time() - last_log >= 10:
            stats    = producer.stats
            wall     = time.time() - start
            eff_rate = total / wall if wall else 0
            logger.info(
                f"[{wall:>6.0f}s] produced={total:,} "
                f"eff_rate={eff_rate:.0f}/s "
                f"errors={stats['errors']} dlq={stats['dlq_sent']}"
            )
            last_log = time.time()

    producer.flush()
    stats = producer.stats
    logger.info(
        f"Producer finished. Total sent={stats['sent']:,} "
        f"errors={stats['errors']} dlq={stats['dlq_sent']}"
    )


def main():
    import yaml
    parser = argparse.ArgumentParser(description="Clickstream Kafka producer")
    parser.add_argument("--rate",     type=int,   default=100,      help="Events per second")
    parser.add_argument("--duration", type=int,   default=None,     help="Run duration in seconds (default: run forever)")
    parser.add_argument("--mode",     type=str,   default="steady", choices=["steady", "burst", "session"])
    parser.add_argument("--config",   type=str,   default="config/pipeline_config.yml")
    args = parser.parse_args()

    with open(args.config) as f:
        config = yaml.safe_load(f)

    run(args.rate, args.duration, args.mode, config)


if __name__ == "__main__":
    main()
