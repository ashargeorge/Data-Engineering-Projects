"""Streaming pipeline"""
