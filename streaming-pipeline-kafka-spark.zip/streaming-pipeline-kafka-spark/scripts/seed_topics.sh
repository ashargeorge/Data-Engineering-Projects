#!/usr/bin/env bash
# Creates Kafka topics with appropriate partition counts and retention settings.
set -euo pipefail

KAFKA_CONTAINER=$(docker-compose ps -q kafka)
BOOTSTRAP="localhost:9092"

echo "Creating Kafka topics..."

docker exec "$KAFKA_CONTAINER" kafka-topics --create \
  --bootstrap-server "$BOOTSTRAP" \
  --topic clickstream-events \
  --partitions 6 \
  --replication-factor 1 \
  --config retention.ms=86400000 \
  --if-not-exists

docker exec "$KAFKA_CONTAINER" kafka-topics --create \
  --bootstrap-server "$BOOTSTRAP" \
  --topic clickstream-dlq \
  --partitions 1 \
  --replication-factor 1 \
  --config retention.ms=604800000 \
  --if-not-exists

echo "Topics created:"
docker exec "$KAFKA_CONTAINER" kafka-topics --list --bootstrap-server "$BOOTSTRAP"
