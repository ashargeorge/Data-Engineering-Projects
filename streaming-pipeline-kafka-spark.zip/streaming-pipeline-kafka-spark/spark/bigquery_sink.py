"""BigQuery sink configuration and table schema definitions."""

from dataclasses import dataclass


@dataclass
class BigQuerySink:
    """Holds references to all BigQuery tables written by the streaming job."""
    project:         str
    dataset:         str
    gcs_temp_bucket: str

    @property
    def raw_events_table(self) -> str:
        return f"{self.project}:{self.dataset}.clickstream_events"

    @property
    def session_metrics_table(self) -> str:
        return f"{self.project}:{self.dataset}.session_metrics"

    @property
    def product_metrics_table(self) -> str:
        return f"{self.project}:{self.dataset}.product_metrics"

    @property
    def funnel_metrics_table(self) -> str:
        return f"{self.project}:{self.dataset}.funnel_metrics"


# BigQuery table DDL (for reference / Terraform)
TABLE_SCHEMAS = {
    "clickstream_events": """
        event_id         STRING NOT NULL,
        user_id          STRING NOT NULL,
        session_id       STRING NOT NULL,
        event_type       STRING NOT NULL,
        product_id       STRING,
        product_category STRING,
        amount           FLOAT64,
        page_url         STRING,
        device_type      STRING,
        country          STRING,
        timestamp        TIMESTAMP NOT NULL,
        is_purchase      BOOL,
        is_add_to_cart   BOOL,
        revenue          FLOAT64,
        event_date       DATE
    """,
    "session_metrics": """
        window_start     TIMESTAMP NOT NULL,
        window_end       TIMESTAMP NOT NULL,
        session_id       STRING NOT NULL,
        user_id          STRING NOT NULL,
        device_type      STRING,
        country          STRING,
        event_count      INT64,
        page_views       INT64,
        product_views    INT64,
        add_to_carts     INT64,
        purchases        INT64,
        total_revenue    FLOAT64,
        converted        BOOL,
        session_start    TIMESTAMP,
        session_end      TIMESTAMP
    """,
    "product_metrics": """
        window_start     TIMESTAMP NOT NULL,
        window_end       TIMESTAMP NOT NULL,
        product_id       STRING NOT NULL,
        product_category STRING,
        views            INT64,
        add_to_carts     INT64,
        purchases        INT64,
        total_revenue    FLOAT64,
        conversion_rate  FLOAT64
    """,
    "funnel_metrics": """
        window_start            TIMESTAMP NOT NULL,
        window_end              TIMESTAMP NOT NULL,
        page_views              INT64,
        product_views           INT64,
        add_to_carts            INT64,
        checkouts               INT64,
        purchases               INT64,
        total_revenue           FLOAT64,
        unique_sessions         INT64,
        unique_users            INT64,
        session_conversion_rate FLOAT64
    """,
}
