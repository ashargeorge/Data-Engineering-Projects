"""
Main PySpark Structured Streaming job.

Reads from Kafka → parses → enriches → aggregates → writes to BigQuery.

Submit with:
  spark-submit \
    --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0,\
com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.36.1 \
    spark/streaming_job.py --config config/pipeline_config.yml
"""

import argparse
import logging
import os
import sys
import yaml

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from spark.transformations import (
    parse_kafka_stream,
    enrich_events,
    compute_session_metrics,
    compute_product_metrics,
    compute_realtime_funnel,
)
from spark.bigquery_sink import BigQuerySink

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


def build_spark_session(app_name: str, gcp_project: str) -> SparkSession:
    return (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.streaming.checkpointLocation", os.getenv(
            "GCS_CHECKPOINT_BUCKET", "/tmp/spark-checkpoints"
        ))
        .config("spark.sql.shuffle.partitions", "8")
        .config("spark.streaming.stopGracefullyOnShutdown", "true")
        .config("parentProject", gcp_project)
        .config("spark.sql.streaming.forceDeleteTempCheckpointLocation", "true")
        .getOrCreate()
    )


def read_kafka_stream(spark: SparkSession, config: dict):
    kafka_cfg  = config["kafka"]
    bootstrap  = os.getenv("KAFKA_BOOTSTRAP_SERVERS", kafka_cfg["bootstrap_servers"])
    topic      = os.getenv("KAFKA_TOPIC", kafka_cfg["topic"])

    logger.info(f"Subscribing to Kafka topic: {topic} @ {bootstrap}")

    return (
        spark.readStream
        .format("kafka")
        .option("kafka.bootstrap.servers", bootstrap)
        .option("subscribe", topic)
        .option("startingOffsets", "latest")
        .option("maxOffsetsPerTrigger", 50_000)
        .option("kafka.group.id", "spark-clickstream-consumer")
        .option("failOnDataLoss", "false")
        .load()
    )


def write_raw_events(df, sink: BigQuerySink, checkpoint_path: str):
    """Write raw enriched events to BigQuery (append only)."""
    return (
        df
        .select(
            "event_id", "user_id", "session_id", "event_type",
            "product_id", "product_category", "amount",
            "page_url", "device_type", "country", "timestamp",
            "is_purchase", "is_add_to_cart", "revenue", "event_date",
        )
        .writeStream
        .format("bigquery")
        .option("table", sink.raw_events_table)
        .option("checkpointLocation", f"{checkpoint_path}/raw_events")
        .option("temporaryGcsBucket", sink.gcs_temp_bucket)
        .outputMode("append")
        .trigger(processingTime="10 seconds")
        .start()
    )


def write_session_metrics(df, sink: BigQuerySink, checkpoint_path: str):
    return (
        df
        .writeStream
        .format("bigquery")
        .option("table", sink.session_metrics_table)
        .option("checkpointLocation", f"{checkpoint_path}/session_metrics")
        .option("temporaryGcsBucket", sink.gcs_temp_bucket)
        .outputMode("append")
        .trigger(processingTime="30 seconds")
        .start()
    )


def write_product_metrics(df, sink: BigQuerySink, checkpoint_path: str):
    return (
        df
        .writeStream
        .format("bigquery")
        .option("table", sink.product_metrics_table)
        .option("checkpointLocation", f"{checkpoint_path}/product_metrics")
        .option("temporaryGcsBucket", sink.gcs_temp_bucket)
        .outputMode("append")
        .trigger(processingTime="30 seconds")
        .start()
    )


def write_funnel_metrics(df, sink: BigQuerySink, checkpoint_path: str):
    return (
        df
        .writeStream
        .format("bigquery")
        .option("table", sink.funnel_metrics_table)
        .option("checkpointLocation", f"{checkpoint_path}/funnel_metrics")
        .option("temporaryGcsBucket", sink.gcs_temp_bucket)
        .outputMode("append")
        .trigger(processingTime="30 seconds")
        .start()
    )


def main(config_path: str) -> None:
    with open(config_path) as f:
        config = yaml.safe_load(f)

    gcp_project     = os.getenv("GCP_PROJECT_ID", config["gcp"]["project_id"])
    bq_dataset      = os.getenv("BIGQUERY_DATASET", config["gcp"]["bigquery_dataset"])
    gcs_checkpoint  = os.getenv("GCS_CHECKPOINT_BUCKET", config["gcp"]["checkpoint_bucket"])
    gcs_temp_bucket = config["gcp"].get("temp_bucket", gcs_checkpoint)

    spark = build_spark_session("clickstream-streaming-pipeline", gcp_project)
    spark.sparkContext.setLogLevel("WARN")
    logger.info("Spark session started")

    sink = BigQuerySink(
        project=gcp_project,
        dataset=bq_dataset,
        gcs_temp_bucket=gcs_temp_bucket,
    )

    # ── Read ──────────────────────────────────────────────────────
    raw_stream = read_kafka_stream(spark, config)

    # ── Parse + Enrich ────────────────────────────────────────────
    parsed   = parse_kafka_stream(raw_stream)
    enriched = enrich_events(parsed)

    # ── Aggregate ─────────────────────────────────────────────────
    session_metrics = compute_session_metrics(enriched)
    product_metrics = compute_product_metrics(enriched)
    funnel_metrics  = compute_realtime_funnel(enriched)

    # ── Write ─────────────────────────────────────────────────────
    queries = [
        write_raw_events(enriched, sink, gcs_checkpoint),
        write_session_metrics(session_metrics, sink, gcs_checkpoint),
        write_product_metrics(product_metrics, sink, gcs_checkpoint),
        write_funnel_metrics(funnel_metrics, sink, gcs_checkpoint),
    ]

    logger.info(f"Started {len(queries)} streaming queries. Awaiting termination...")
    spark.streams.awaitAnyTermination()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Clickstream Spark streaming job")
    parser.add_argument("--config", default="config/pipeline_config.yml")
    args = parser.parse_args()
    main(args.config)
