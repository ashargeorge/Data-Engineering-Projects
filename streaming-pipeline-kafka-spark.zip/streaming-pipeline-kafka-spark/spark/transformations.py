"""
PySpark transformation functions for clickstream data.

Includes:
- Schema definition matching the Kafka event model
- Stateless column enrichment
- Windowed session aggregations with watermarking
- Windowed product aggregations
"""

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField,
    StringType, DoubleType, TimestampType, BooleanType,
)

# -----------------------------------------------------------------
# Schema
# -----------------------------------------------------------------
CLICKSTREAM_SCHEMA = StructType([
    StructField("event_id",         StringType(),    False),
    StructField("user_id",          StringType(),    False),
    StructField("session_id",       StringType(),    False),
    StructField("event_type",       StringType(),    False),
    StructField("product_id",       StringType(),    True),
    StructField("product_category", StringType(),    True),
    StructField("amount",           DoubleType(),    True),
    StructField("page_url",         StringType(),    False),
    StructField("device_type",      StringType(),    False),
    StructField("country",          StringType(),    False),
    StructField("timestamp",        TimestampType(), False),
])

VALID_EVENT_TYPES   = {"page_view", "product_view", "add_to_cart", "checkout", "purchase"}
VALID_DEVICE_TYPES  = {"mobile", "desktop", "tablet"}
WINDOW_DURATION     = "1 minute"
WATERMARK_THRESHOLD = "10 minutes"


# -----------------------------------------------------------------
# Parse + validate raw Kafka messages
# -----------------------------------------------------------------
def parse_kafka_stream(raw_df: DataFrame) -> DataFrame:
    """
    Parse raw Kafka bytes into a structured DataFrame.
    Malformed records are filtered out (routed to DLQ by producer).
    """
    return (
        raw_df
        .select(
            F.col("key").cast(StringType()).alias("kafka_key"),
            F.from_json(
                F.col("value").cast(StringType()),
                CLICKSTREAM_SCHEMA,
            ).alias("data"),
            F.col("timestamp").alias("kafka_timestamp"),
            F.col("partition"),
            F.col("offset"),
        )
        .select("kafka_key", "data.*", "kafka_timestamp", "partition", "offset")
        .filter(F.col("event_id").isNotNull())
        .filter(F.col("user_id").isNotNull())
        .filter(F.col("session_id").isNotNull())
    )


# -----------------------------------------------------------------
# Enrichment
# -----------------------------------------------------------------
def enrich_events(df: DataFrame) -> DataFrame:
    """Add derived columns useful for downstream aggregations."""
    return (
        df
        .withColumn("is_purchase",     F.col("event_type") == "purchase")
        .withColumn("is_add_to_cart",  F.col("event_type") == "add_to_cart")
        .withColumn("is_product_view", F.col("event_type") == "product_view")
        .withColumn("is_page_view",    F.col("event_type") == "page_view")
        .withColumn("revenue",         F.coalesce(F.col("amount"), F.lit(0.0)))
        .withColumn("event_hour",      F.hour("timestamp"))
        .withColumn("event_date",      F.to_date("timestamp"))
        # Validate event types — flag unknowns
        .withColumn(
            "is_valid_event",
            F.col("event_type").isin(list(VALID_EVENT_TYPES)),
        )
    )


# -----------------------------------------------------------------
# Windowed aggregations
# -----------------------------------------------------------------
def compute_session_metrics(df: DataFrame) -> DataFrame:
    """
    Aggregate per-session metrics in 1-minute tumbling windows
    with a 10-minute watermark for late-arriving data.

    Output schema:
      window, session_id, user_id, device_type, country,
      event_count, page_views, product_views, add_to_carts,
      purchases, total_revenue, converted
    """
    return (
        df
        .withWatermark("timestamp", WATERMARK_THRESHOLD)
        .groupBy(
            F.window("timestamp", WINDOW_DURATION),
            "session_id",
            "user_id",
            "device_type",
            "country",
        )
        .agg(
            F.count("*").alias("event_count"),
            F.sum(F.col("is_page_view").cast("int")).alias("page_views"),
            F.sum(F.col("is_product_view").cast("int")).alias("product_views"),
            F.sum(F.col("is_add_to_cart").cast("int")).alias("add_to_carts"),
            F.sum(F.col("is_purchase").cast("int")).alias("purchases"),
            F.sum("revenue").alias("total_revenue"),
            F.max("is_purchase").alias("converted"),
            F.min("timestamp").alias("session_start"),
            F.max("timestamp").alias("session_end"),
        )
        .select(
            F.col("window.start").alias("window_start"),
            F.col("window.end").alias("window_end"),
            "session_id", "user_id", "device_type", "country",
            "event_count", "page_views", "product_views",
            "add_to_carts", "purchases",
            F.round("total_revenue", 2).alias("total_revenue"),
            "converted", "session_start", "session_end",
        )
    )


def compute_product_metrics(df: DataFrame) -> DataFrame:
    """
    Aggregate per-product metrics in 1-minute tumbling windows.

    Output schema:
      window, product_id, product_category,
      views, add_to_carts, purchases, total_revenue, conversion_rate
    """
    product_df = df.filter(F.col("product_id").isNotNull())

    return (
        product_df
        .withWatermark("timestamp", WATERMARK_THRESHOLD)
        .groupBy(
            F.window("timestamp", WINDOW_DURATION),
            "product_id",
            "product_category",
        )
        .agg(
            F.sum(F.col("is_product_view").cast("int")).alias("views"),
            F.sum(F.col("is_add_to_cart").cast("int")).alias("add_to_carts"),
            F.sum(F.col("is_purchase").cast("int")).alias("purchases"),
            F.sum("revenue").alias("total_revenue"),
        )
        .withColumn(
            "conversion_rate",
            F.when(F.col("views") > 0,
                   F.round(F.col("purchases") / F.col("views"), 4)
            ).otherwise(F.lit(0.0)),
        )
        .select(
            F.col("window.start").alias("window_start"),
            F.col("window.end").alias("window_end"),
            "product_id", "product_category",
            "views", "add_to_carts", "purchases",
            F.round("total_revenue", 2).alias("total_revenue"),
            "conversion_rate",
        )
    )


def compute_realtime_funnel(df: DataFrame) -> DataFrame:
    """
    Compute conversion funnel counts per 1-minute window.
    Useful for live Grafana funnel charts.
    """
    return (
        df
        .withWatermark("timestamp", WATERMARK_THRESHOLD)
        .groupBy(F.window("timestamp", WINDOW_DURATION))
        .agg(
            F.sum(F.col("is_page_view").cast("int")).alias("page_views"),
            F.sum(F.col("is_product_view").cast("int")).alias("product_views"),
            F.sum(F.col("is_add_to_cart").cast("int")).alias("add_to_carts"),
            F.sum((F.col("event_type") == "checkout").cast("int")).alias("checkouts"),
            F.sum(F.col("is_purchase").cast("int")).alias("purchases"),
            F.sum("revenue").alias("total_revenue"),
            F.approx_count_distinct("session_id").alias("unique_sessions"),
            F.approx_count_distinct("user_id").alias("unique_users"),
        )
        .select(
            F.col("window.start").alias("window_start"),
            F.col("window.end").alias("window_end"),
            "page_views", "product_views", "add_to_carts",
            "checkouts", "purchases",
            F.round("total_revenue", 2).alias("total_revenue"),
            "unique_sessions", "unique_users",
            F.when(F.col("unique_sessions") > 0,
                   F.round(F.col("purchases") / F.col("unique_sessions"), 4)
            ).otherwise(F.lit(0.0)).alias("session_conversion_rate"),
        )
    )
