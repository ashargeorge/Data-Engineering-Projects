terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# ── BigQuery ──────────────────────────────────────────────────────

resource "google_bigquery_dataset" "clickstream" {
  dataset_id    = var.bigquery_dataset
  friendly_name = "Clickstream Analytics"
  description   = "Real-time e-commerce clickstream metrics"
  location      = var.region

  labels = {
    environment = var.environment
    managed_by  = "terraform"
  }
}

resource "google_bigquery_table" "clickstream_events" {
  dataset_id          = google_bigquery_dataset.clickstream.dataset_id
  table_id            = "clickstream_events"
  deletion_protection = false

  time_partitioning {
    type  = "DAY"
    field = "event_date"
  }

  clustering = ["event_type", "country", "device_type"]

  schema = file("${path.module}/schemas/clickstream_events.json")
}

resource "google_bigquery_table" "session_metrics" {
  dataset_id          = google_bigquery_dataset.clickstream.dataset_id
  table_id            = "session_metrics"
  deletion_protection = false

  time_partitioning {
    type  = "HOUR"
    field = "window_start"
  }

  schema = file("${path.module}/schemas/session_metrics.json")
}

resource "google_bigquery_table" "funnel_metrics" {
  dataset_id          = google_bigquery_dataset.clickstream.dataset_id
  table_id            = "funnel_metrics"
  deletion_protection = false

  time_partitioning {
    type  = "HOUR"
    field = "window_start"
  }

  schema = file("${path.module}/schemas/funnel_metrics.json")
}

# ── GCS Buckets ───────────────────────────────────────────────────

resource "google_storage_bucket" "spark_checkpoints" {
  name          = "${var.project_id}-spark-checkpoints"
  location      = var.region
  force_destroy = false

  lifecycle_rule {
    condition { age = 7 }
    action    { type = "Delete" }
  }

  versioning { enabled = false }
}

resource "google_storage_bucket" "spark_temp" {
  name          = "${var.project_id}-spark-temp"
  location      = var.region
  force_destroy = true

  lifecycle_rule {
    condition { age = 1 }
    action    { type = "Delete" }
  }
}

# ── Service Account ───────────────────────────────────────────────

resource "google_service_account" "streaming_pipeline" {
  account_id   = "streaming-pipeline-sa"
  display_name = "Streaming Pipeline Service Account"
}

resource "google_project_iam_member" "bigquery_editor" {
  project = var.project_id
  role    = "roles/bigquery.dataEditor"
  member  = "serviceAccount:${google_service_account.streaming_pipeline.email}"
}

resource "google_project_iam_member" "storage_admin" {
  project = var.project_id
  role    = "roles/storage.objectAdmin"
  member  = "serviceAccount:${google_service_account.streaming_pipeline.email}"
}

resource "google_service_account_key" "streaming_pipeline_key" {
  service_account_id = google_service_account.streaming_pipeline.name
}
