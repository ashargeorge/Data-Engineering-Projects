output "bigquery_dataset_id" {
  value = google_bigquery_dataset.clickstream.dataset_id
}

output "checkpoint_bucket" {
  value = google_storage_bucket.spark_checkpoints.name
}

output "temp_bucket" {
  value = google_storage_bucket.spark_temp.name
}

output "service_account_email" {
  value = google_service_account.streaming_pipeline.email
}

output "service_account_key" {
  value     = google_service_account_key.streaming_pipeline_key.private_key
  sensitive = true
}
