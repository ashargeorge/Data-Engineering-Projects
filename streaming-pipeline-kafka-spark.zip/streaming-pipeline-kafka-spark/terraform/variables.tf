variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "bigquery_dataset" {
  description = "BigQuery dataset name"
  type        = string
  default     = "clickstream"
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  default     = "production"
}
