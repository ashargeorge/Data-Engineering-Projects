"""Tests for the DLQ consumer report generation."""

import json
import pytest
from unittest.mock import MagicMock, patch
from consumer.dlq_consumer import DLQConsumer


SAMPLE_CONFIG = {
    "kafka": {
        "bootstrap_servers": "localhost:9092",
        "dlq_topic": "clickstream-dlq",
    },
    "dlq": {"report_path": "/tmp/test_dlq_report.json"},
}


@pytest.fixture
def dlq_consumer():
    with patch("consumer.dlq_consumer.Consumer") as mock_consumer_cls:
        mock_instance = MagicMock()
        mock_consumer_cls.return_value = mock_instance
        consumer = DLQConsumer(SAMPLE_CONFIG)
        consumer._consumer = mock_instance
        yield consumer


def test_write_report_creates_file(dlq_consumer, tmp_path):
    dlq_consumer.report_path = str(tmp_path / "report.json")
    # Inject some fake messages
    dlq_consumer._messages = [
        {"original_event": {}, "error_reason": "null_user_id", "dlq_timestamp": "2024-01-01T00:00:00Z"},
        {"original_event": {}, "error_reason": "schema_mismatch", "dlq_timestamp": "2024-01-01T00:01:00Z"},
        {"original_event": {}, "error_reason": "null_user_id", "dlq_timestamp": "2024-01-01T00:02:00Z"},
    ]
    from collections import Counter
    dlq_consumer._errors = Counter(m["error_reason"] for m in dlq_consumer._messages)

    report = dlq_consumer.write_report()

    assert report["total_dlq"] == 3
    assert report["error_counts"]["null_user_id"] == 2
    assert report["error_counts"]["schema_mismatch"] == 1
    assert len(report["sample_errors"]) <= 10


def test_report_json_is_valid(dlq_consumer, tmp_path):
    dlq_consumer.report_path = str(tmp_path / "report.json")
    dlq_consumer._messages = []
    from collections import Counter
    dlq_consumer._errors = Counter()
    dlq_consumer.write_report()

    with open(dlq_consumer.report_path) as f:
        data = json.load(f)
    assert "generated_at" in data
    assert "total_dlq" in data
