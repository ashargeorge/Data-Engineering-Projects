"""Tests for the event generator — validates funnel logic and data shapes."""

import pytest
from collections import Counter
from producer.event_generator import generate_session_events, generate_single_event
from producer.event_models import ClickstreamEvent, EventType


def test_generate_single_event_returns_event():
    event = generate_single_event()
    assert isinstance(event, ClickstreamEvent)


def test_generate_session_returns_list():
    events = generate_session_events()
    assert isinstance(events, list)
    assert len(events) >= 1


def test_session_events_share_session_id():
    events = generate_session_events()
    session_ids = {e.session_id for e in events}
    assert len(session_ids) == 1


def test_session_events_share_user_id():
    events = generate_session_events()
    user_ids = {e.user_id for e in events}
    assert len(user_ids) == 1


def test_event_type_is_valid():
    valid_types = set(EventType)
    for _ in range(50):
        event = generate_single_event()
        assert event.event_type in valid_types


def test_purchase_events_have_positive_amount():
    # Generate enough events to get at least one purchase
    events = []
    for _ in range(100):
        events.extend(generate_session_events())
    purchases = [e for e in events if e.event_type == EventType.PURCHASE]
    if purchases:
        for p in purchases:
            assert p.amount is not None
            assert p.amount > 0


def test_non_purchase_events_amount_is_none_or_zero():
    events = []
    for _ in range(20):
        events.extend(generate_session_events())
    non_purchases = [e for e in events if e.event_type != EventType.PURCHASE]
    for e in non_purchases:
        assert e.amount is None or e.amount == 0


def test_product_events_have_product_id():
    product_types = {EventType.PRODUCT_VIEW, EventType.ADD_TO_CART, EventType.PURCHASE}
    events = []
    for _ in range(30):
        events.extend(generate_session_events())
    for e in events:
        if e.event_type in product_types:
            assert e.product_id is not None
            assert e.product_category is not None


def test_to_kafka_dict_is_serialisable():
    import json
    event = generate_single_event()
    d = event.to_kafka_dict()
    # Must not raise
    serialised = json.dumps(d)
    assert isinstance(serialised, str)


def test_to_kafka_dict_timestamp_is_string():
    event = generate_single_event()
    d = event.to_kafka_dict()
    assert isinstance(d["timestamp"], str)


def test_funnel_order_respected_over_many_sessions():
    """
    Checkout should never appear before add_to_cart in a session.
    Purchase should never appear before checkout.
    """
    for _ in range(200):
        events = generate_session_events()
        types  = [e.event_type for e in events]
        if EventType.PURCHASE in types:
            purchase_idx = types.index(EventType.PURCHASE)
            checkout_idx = types.index(EventType.CHECKOUT) if EventType.CHECKOUT in types else -1
            if checkout_idx != -1:
                assert checkout_idx < purchase_idx, "CHECKOUT must come before PURCHASE"
