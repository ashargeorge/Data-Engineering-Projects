"""
Unit tests for PySpark transformations.
Uses a local SparkSession — no cluster needed.
"""

import pytest
from datetime import datetime, timedelta
from unittest.mock import patch

# Guard: skip all tests if PySpark is not installed
pytest.importorskip("pyspark")

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType, BooleanType

from spark.transformations import (
    CLICKSTREAM_SCHEMA,
    enrich_events,
    compute_session_metrics,
    compute_product_metrics,
    compute_realtime_funnel,
)


@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder
        .master("local[2]")
        .appName("test-transformations")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )


@pytest.fixture
def sample_events(spark):
    now = datetime.utcnow()
    data = [
        ("e1", "u1", "s1", "page_view",    None,  None,        None,   "/",        "mobile",  "NG", now),
        ("e2", "u1", "s1", "product_view", "P001","Electronics",None,   "/products","mobile",  "NG", now),
        ("e3", "u1", "s1", "add_to_cart",  "P001","Electronics",None,   "/cart",    "mobile",  "NG", now),
        ("e4", "u1", "s1", "purchase",     "P001","Electronics",99.99,  "/checkout","mobile",  "NG", now),
        ("e5", "u2", "s2", "page_view",    None,  None,        None,   "/",        "desktop", "US", now),
        ("e6", "u2", "s2", "product_view", "P002","Electronics",None,   "/products","desktop", "US", now),
    ]
    schema = StructType([
        StructField("event_id",         StringType(),    False),
        StructField("user_id",          StringType(),    False),
        StructField("session_id",       StringType(),    False),
        StructField("event_type",       StringType(),    False),
        StructField("product_id",       StringType(),    True),
        StructField("product_category", StringType(),    True),
        StructField("amount",           DoubleType(),    True),
        StructField("page_url",         StringType(),    False),
        StructField("device_type",      StringType(),    False),
        StructField("country",          StringType(),    False),
        StructField("timestamp",        TimestampType(), False),
    ])
    return spark.createDataFrame(data, schema)


# ── enrich_events ──────────────────────────────────────────────────

def test_enrich_adds_is_purchase_column(sample_events):
    df = enrich_events(sample_events)
    assert "is_purchase" in df.columns


def test_enrich_is_purchase_correct(sample_events):
    df = enrich_events(sample_events)
    purchases = df.filter(F.col("is_purchase") == True).count()
    assert purchases == 1


def test_enrich_revenue_defaults_to_zero_for_non_purchase(sample_events):
    df = enrich_events(sample_events)
    non_purchase = df.filter(F.col("event_type") != "purchase")
    zero_revenue = non_purchase.filter(F.col("revenue") == 0.0).count()
    assert zero_revenue == non_purchase.count()


def test_enrich_adds_event_date(sample_events):
    df = enrich_events(sample_events)
    assert "event_date" in df.columns
    assert df.filter(F.col("event_date").isNull()).count() == 0


def test_enrich_is_valid_event_flags_unknown(spark, sample_events):
    from pyspark.sql.types import Row
    now = datetime.utcnow()
    bad_row = spark.createDataFrame(
        [("e99", "u9", "s9", "unknown_type", None, None, None, "/", "mobile", "NG", now)],
        schema=sample_events.schema,
    )
    df = enrich_events(bad_row)
    assert df.filter(F.col("is_valid_event") == False).count() == 1


# ── compute_session_metrics ────────────────────────────────────────

def test_session_metrics_returns_correct_session_count(sample_events):
    enriched = enrich_events(sample_events)
    metrics  = compute_session_metrics(enriched)
    # Two unique sessions in sample data
    assert metrics.count() == 2


def test_session_metrics_converted_flag(sample_events):
    enriched = enrich_events(sample_events)
    metrics  = compute_session_metrics(enriched)
    s1 = metrics.filter(F.col("session_id") == "s1").first()
    s2 = metrics.filter(F.col("session_id") == "s2").first()
    assert s1["converted"] is True
    assert s2["converted"] is False


def test_session_metrics_purchase_count(sample_events):
    enriched = enrich_events(sample_events)
    metrics  = compute_session_metrics(enriched)
    s1 = metrics.filter(F.col("session_id") == "s1").first()
    assert s1["purchases"] == 1


def test_session_metrics_total_revenue(sample_events):
    enriched = enrich_events(sample_events)
    metrics  = compute_session_metrics(enriched)
    s1 = metrics.filter(F.col("session_id") == "s1").first()
    assert abs(s1["total_revenue"] - 99.99) < 0.01


# ── compute_product_metrics ────────────────────────────────────────

def test_product_metrics_filters_null_product_ids(sample_events):
    enriched = enrich_events(sample_events)
    metrics  = compute_product_metrics(enriched)
    # Only events with product_id — P001 and P002
    assert metrics.count() <= 2


def test_product_metrics_conversion_rate_between_0_and_1(sample_events):
    enriched = enrich_events(sample_events)
    metrics  = compute_product_metrics(enriched)
    bad = metrics.filter(
        (F.col("conversion_rate") < 0) | (F.col("conversion_rate") > 1)
    ).count()
    assert bad == 0


# ── compute_realtime_funnel ────────────────────────────────────────

def test_funnel_metrics_has_window_columns(sample_events):
    enriched = enrich_events(sample_events)
    funnel   = compute_realtime_funnel(enriched)
    assert "window_start" in funnel.columns
    assert "window_end"   in funnel.columns


def test_funnel_metrics_total_revenue(sample_events):
    enriched = enrich_events(sample_events)
    funnel   = compute_realtime_funnel(enriched)
    total    = funnel.agg(F.sum("total_revenue")).first()[0]
    assert abs(total - 99.99) < 0.01
